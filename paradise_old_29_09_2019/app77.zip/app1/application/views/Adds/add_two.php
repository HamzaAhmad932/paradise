<section class="hot-offers text-center pt-0 pb-0">
<h6 class="sr-only">Services List</h6>
         <div class="container">
            <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12">
                  <a href="#">
                  <img src="<?php echo base_url('assets/images/offers/home1_bn1.png'); ?>" alt="">
                  </a>
               </div>
            </div>
         </div>
      </section>