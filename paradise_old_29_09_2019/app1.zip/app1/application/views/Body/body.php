      <section class="banner-area hot-offers">
         <div class="container">
            <div class="row">
               <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
                  <div class="banner-block mt-0">
                     <a href="#"> <img src="<?php echo base_url('assets/images/offers-list/1.jpg'); ?>" alt="banner collection"> </a>
                     <div class="text-des-container pad-zero">
                        <div class="text-des">
                           <h2>Product Name</h2>
                           <p>Lorem Ipsum is simply dummy!</p>
                           <a class="btn btn-primary" href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-xs-12 col-sm-6 col-lg-6 col-md-6">
                        <div class="banner-block">
                           <a href="#"> <img src="<?php echo base_url('assets/images/offers-list/2.jpg'); ?>" alt="banner sunglasses"> </a>
                           <div class="text-des-container">
                              <div class="text-des">
                                 <h2>Product Name</h2>
                                 <p>Lorem Ipsum is simply dummy!</p>
                                 <a class="btn btn-primary" href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                              </div>
                           </div>
                        </div>
                        <div class="banner-block">
                           <a href="#"> <img src="<?php echo base_url('assets/images/offers-list/3.jpg'); ?>" alt="banner jeans"> </a>
                           <div class="text-des-container pad-zero">
                              <div class="text-des">
                                 <h2>Product Name</h2>
                                 <p>Lorem Ipsum is simply dummy!</p>
                                 <a class="btn btn-primary" href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-xs-12 col-sm-6 col-lg-6 col-md-6">
                        <div class="banner-block">
                           <a href="#"> <img src="<?php echo base_url('assets/images/offers-list/4.jpg'); ?>" alt="banner kids"> </a>
                           <div class="text-des-container">
                              <div class="text-des">
                                 <h2>Product Name</h2>
                                 <p>Lorem Ipsum is simply dummy!</p>
                                 <a class="btn btn-primary" href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                              </div>
                           </div>
                        </div>
                        <div class="banner-block">
                           <a href="#"> <img src="<?php echo base_url('assets/images/offers-list/5.jpg'); ?>" alt="banner women"> </a>
                           <div class="text-des-container">
                              <div class="text-des">
                                 <h2>Product Name</h2>
                                 <p>Lorem Ipsum is simply dummy!</p>
                                 <a class="btn btn-primary" href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                              </div>
                           </div>
                        </div>
                        <div class="banner-block">
                           <a href="#"> <img src="<?php echo base_url('assets/images/offers-list/6.jpg'); ?>" alt="banner beauty"> </a>
                           <div class="text-des-container">
                              <div class="text-des">
                                 <h2>Product Name</h2>
                                 <p>Lorem Ipsum is simply dummy!</p>
                                 <a class="btn btn-primary" href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xs-12 col-sm-4 col-lg-4 col-md-4">
                  <div class="banner-block mt-0">
                     <a href="#"> <img src="<?php echo base_url('assets/images/offers-list/7.jpg'); ?>" alt="banner arrival"> </a>
                     <div class="text-des-container">
                        <div class="text-des">
                           <h2>Product Name</h2>
                           <p>Lorem Ipsum is simply dummy!</p>
                           <a class="btn btn-primary" href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                        </div>
                     </div>
                  </div>
                  <div class="banner-block">
                     <a href="#"> <img src="<?php echo base_url('assets/images/offers-list/8.jpg'); ?>" alt="banner watch"> </a>
                     <div class="text-des-container">
                        <div class="text-des">
                           <h2>Product Name</h2>
                           <p>Lorem Ipsum is simply dummy!</p>
                           <a class="btn btn-primary" href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                        </div>
                     </div>
                  </div>
                  <div class="banner-block">
                     <a href="#"> <img src="<?php echo base_url('assets/images/offers-list/9.jpg'); ?>" alt="banner look"> </a>
                     <div class="text-des-container">
                        <div class="text-des">
                           <h2>Product Name</h2>
                           <p>Lorem Ipsum is simply dummy!</p>
                           <a class="btn btn-primary" href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>