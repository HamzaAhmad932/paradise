    <div class="hot-offers pt-0 pb-0 ads-two">
         <div class="container">
            <div class="row">
               <div class="col-lg-6 col-md-6 col-sm-6">
                  <a href="#">
                  <img src="<?php echo base_url('assets/images/offers/home2_banner_2.jpg'); ?>" alt="">
                  </a>
               </div>
               <div class="col-lg-6 col-md-6 col-sm-6">
                  <a href="#">
                  <img src="<?php echo base_url('assets/images/offers/home2_banner_3.jpg'); ?>" alt="">
                  </a>
               </div>
            </div>
         </div>
      </div>