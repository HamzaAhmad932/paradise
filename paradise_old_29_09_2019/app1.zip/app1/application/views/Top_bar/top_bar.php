      <div class="navbar-top navbar-top-2">
         <div class="container">
            <div class="row">
               <div class="col-lg-6 col-sm-6 col-xs-6 col-md-6 text-left">
                   
               </div>
               <div class="col-lg-6 col-sm-6 col-xs-6 col-md-6 text-right">
                  <ul class="list-inline">
                     <li class="list-inline-item">
                        <a href="#" style="color: #BB90BB !important;"><i class="fa fa-mobile" aria-hidden="true" style="font-size: 20px;"></i> 923008666704</a>
                     </li>
                     <li class="list-inline-item">
                        <a href="#" style="color: #BB90BB !important;"><i class="fa fa-headphones" aria-hidden="true" style="font-size: 20px;"></i> Contact Us</a>
                     </li>
                     
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <nav class="navbar navbar-light navbar-expand-lg bg-primary bg-faded osahan-menu osahan-menu-top-2">
         <div class="container">
            <a class="navbar-brand" href="index.html"> <img src="<?php echo base_url('assets/images/par_logo.png'); ?>" width="129" hegiht="30" alt="logo"> </a>
            <button class="navbar-toggler navbar-toggler-white" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="navbar-collapse" id="navbarNavDropdown">
               <div class="navbar-nav mr-auto mt-2 mt-lg-0 margin-auto top-categories-search-main">
                  <div class="top-categories-search">
                     <div class="input-group">
                        <span class="input-group-btn categories-dropdown">
                           <select class="form-control">
                              <option selected="selected">All Categories</option>
                              <optgroup label="Android">
                                 <option value="0">Samsung</option>
                                 <option value="2">Micromax</option>
                                 <option value="3">Lenovo</option>
                                 <option value="4">Vivo</option>
                              </optgroup>
                              <optgroup label="iOS">
                                 <option value="5">Apple </option>
                              </optgroup>
                           </select>
                        </span>
                        <input class="form-control" placeholder="Search products & brands" aria-label="Search products & brands" type="text">
                        <span class="input-group-btn">
                        <button class="btn btn-warning" type="button"><i class="fa fa-search" aria-hidden="true"></i> Search</button>
                        </span>
                     </div>
                  </div>
               </div>
               <div class="my-2 my-lg-0">
                  <ul class="list-inline main-nav-right">
                     <li class="list-inline-item dropdown osahan-top-dropdown">
                        <a class="btn btn-outline-light dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-shopping-cart" aria-hidden="true"></i> Cart <small class="cart-value">02</small>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right cart-dropdown">
                           <div class="dropdown-item">                  
                              <a class="pull-right" data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Remove">
                              <i class="fa fa-trash-o"></i>
                              </a>
                              <a href="#">
                              <img class="img-fluid" src="<?php echo base_url('assets/images/all-products/small/1.jpg'); ?>" alt="Product">
                              <strong>Ipsums Dolors Untra </strong>
                              <small>Color : Red | Model: Grand s2</small>
                              <span class="product-desc-price">$529.99</span>
                              <span class="product-price text-danger">$329.99</span>
                              </a>
                           </div>
                           <div class="dropdown-item">                  
                              <a class="pull-right" data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Remove">
                              <i class="fa fa-trash-o"></i>
                              </a>
                              <a href="#">
                              <img class="img-fluid" src="<?php echo base_url('assets/images/all-products/small/3.jpg'); ?>" alt="Product">
                              <strong>Ipsums Dolors Untra </strong>
                              <small>Color : Black | Model: Grand S</small>
                              <span class="product-desc-price">$82.99</span>
                              <span class="product-price text-danger">$36.99</span>
                              </a>
                           </div>
                           <div class="dropdown-item">                  
                              <a class="pull-right" data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Remove">
                              <i class="fa fa-trash-o"></i>
                              </a>
                              <a href="#">
                              <img class="img-fluid" src="<?php echo base_url('assets/images/all-products/small/2.jpg'); ?>" alt="Product">
                              <strong>Ipsums Dolors Untra </strong>
                              <small>Color : white | Model: Grand s2</small>
                              <span class="product-desc-price">$29.99</span>
                              <span class="product-price text-danger">$20.99</span>
                              </a>
                           </div>
                           <div class="dropdown-divider"></div>
                           <div class="dropdown-cart-footer text-center">
                              <h4> <strong>Subtotal</strong>: $210 </h4>
                              <a class="btn btn-sm btn-danger" href="view-cart.html"> <i class="fa fa-shopping-cart" aria-hidden="true"></i> VIEW
                              CART </a> <a href="cart_checkout.html" class="btn btn-sm btn-primary"> CHECKOUT </a>
                           </div>
                        </div>
                     </li>
                     <li class="list-inline-item dropdown osahan-top-dropdown">
                        <a class="btn btn-outline-light dropdown-toggle dropdown-toggle dropdown-toggle-top-user" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="<?php echo base_url('assets/images/user-ava.jpg'); ?>" alt="alt text"> <strong>Hi</strong> Guest
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-list-design">
                           <a class="dropdown-item" href="my-profile.html"><i class="fa fa-user" aria-hidden="true"></i> My Profile</a>
                           <a class="dropdown-item" href="my-address.html"><i class="fa fa-map-marker" aria-hidden="true"></i> My Address</a>
                           <a class="dropdown-item" href="wishlist-user.html"><i class="fa fa-heart" aria-hidden="true"></i> Wish List <span class="badge badge-success">6</span></a>
                           <a class="dropdown-item" href="order-list.html"><i class="fa fa-list-alt" aria-hidden="true"></i> Order List</a>
                           <a class="dropdown-item" href="order-status.html"><i class="fa fa-truck" aria-hidden="true"></i> Order Status</a>
                           <a class="dropdown-item" href="invoice.html"><i class="fa fa-paper-plane" aria-hidden="true"></i> Invoice A4</a>
                           <div class="dropdown-divider"></div>
                           <a class="dropdown-item" href="login.html"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a>
                        </div>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </nav>