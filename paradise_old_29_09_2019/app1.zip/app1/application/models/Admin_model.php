<?php
class Admin_model extends CI_Model{
	public function __Construct(){
		parent::__Construct();
	}
 
}